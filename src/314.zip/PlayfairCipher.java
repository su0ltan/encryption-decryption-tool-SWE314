
public interface PlayfairCipher {

	
	public void printMatrix();
	public String removeWhiteSpace(char[] ch, String key);
	public int[] findIJ(char a, char b, char x[][]);
	public String splitIntoPair(String str);
}
